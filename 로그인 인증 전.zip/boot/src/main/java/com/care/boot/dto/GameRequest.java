package com.care.boot.dto;

public class GameRequest {
    private String move;

    public String getMove() {
        return move;
    }

    public void setMove(String move) {
        this.move = move;
    }
}
