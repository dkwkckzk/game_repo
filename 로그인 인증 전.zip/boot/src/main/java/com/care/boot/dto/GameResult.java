package com.care.boot.dto;

public class GameResult {
    private String playerMove;
    private String serverMove;
    private String result;

    public GameResult(String playerMove, String serverMove, String result) {
        this.playerMove = playerMove;
        this.serverMove = serverMove;
        this.result = result;
    }

    public String getPlayerMove() {
        return playerMove;
    }

    public String getServerMove() {
        return serverMove;
    }

    public String getResult() {
        return result;
    }
}
