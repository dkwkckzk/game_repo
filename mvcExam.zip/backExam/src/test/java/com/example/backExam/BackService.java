package com.example.backExam;

import org.springframework.stereotype.Service;

@Service
public class BackService {
	
	public String registProc(BackDTO datas) {
		System.out.println("아이디 : " + datas.getId());
		System.out.println("비밀번호 : " + datas.getPw());
		System.out.println("비번확인 : " + datas.getConfirm());
		System.out.println("이름 : " + datas.getUserName());
		System.out.println("우편번호 : " + datas.getPostcode());
		System.out.println("주소 : " + datas.getAddress());
		System.out.println("상세주소 : " + datas.getDetailAddress());
		System.out.println("핸드폰번호 : " + datas.getMobile());
	
		return "";
	}
	
	public String loginProc(BackDTO datas) {
		System.out.println("아이디 : " + datas.getId());
		System.out.println("비밀번호 : " + datas.getPw());
		return "";
	}
	
}












