package com.example.cssExam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CssExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
