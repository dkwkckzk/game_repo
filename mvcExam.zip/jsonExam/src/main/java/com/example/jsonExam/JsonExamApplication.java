package com.example.jsonExam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonExamApplication.class, args);
	}

}
