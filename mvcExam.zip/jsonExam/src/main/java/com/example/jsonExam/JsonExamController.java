package com.example.jsonExam;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class JsonExamController {

	@GetMapping("ex01")
	public String ex01() {
		return "ex01";
	}
	
	// 비동기 데이터 응답을 위한 기능
	@ResponseBody
	@PostMapping("ex01")
	public String ex01(@RequestBody(required = false) String data) {
		System.out.println("클라이언트가 보낸 비동기 데이터 : " + data);
		
		if(data == null) {
			return "데이터를 입력하세요.";
		}else if(data.equals("admin") == true) {
			return "아이디가 존재합니다.";
		}
		return "아이디를 사용 할 수 있습니다."; // 비동기 방식에서 서버가 응답 데이터를 담는다.
	}
	
	@GetMapping("ex02")
	public String ex02() {
		return "ex02";
	}
	
	@Autowired JsonExamService service;
	
	@ResponseBody
	@PostMapping("ex02")
	public String ex02(	@RequestBody(required = false) String id) {
		String result = service.ex02(id);
		return result;
	}
	
	@GetMapping("ex03")
	public String ex03() {
		return "ex03";
	}
	
	@GetMapping("ex04")
	public String ex04() {
		return "ex04";
	}

	@ResponseBody
	@PostMapping("ex04")
	public ArrayList<JsonExamDTO> ex04(@RequestBody(required = false) JsonExamDTO datas) {
		System.out.println("아이디: " + datas.getId());
		System.out.println("비밀번호: " + datas.getPw());
		
		// { "title" : "Empire Burlesque", "artist" : "Bob Dylan", "price" : "10.90" }
		// { "title" : "Hide your heart", "artist" : "Bonnie Tyler", "price" : "9.90" }
//		Map<String, String> resData = new HashMap<>();
//		resData.put("title", "Empire Burlesque");
//		resData.put("artist", "Bob Dylan");
//		resData.put("price", "10.90");
		
		JsonExamDTO data1 = new JsonExamDTO();
		data1.setTitle("Empire Burlesque");
		data1.setArtist("Bod Dylan");
		data1.setPrice("10.90");
		
		JsonExamDTO data2 = new JsonExamDTO();
		data2.setTitle("Hide your heart");
		data2.setArtist("Bonnie Tyler");
		data2.setPrice("9.90");
		
		ArrayList<JsonExamDTO> resDatas = new ArrayList<JsonExamDTO>();
		resDatas.add(data1);
		resDatas.add(data2);
		return resDatas;
	}
	/*
	 * JSON과 같은 자료형은 MAP이라는 자료형이 존재함.
	 * JavaScript Object == JAVA Map 자료형
	 * DTO도 가능, 변수의 이름이 Key, 변수 안에 값을 저장
	 */
	
	@GetMapping("ex05")
	public String ex05() {
		return "ex05";
	}
	
	@ResponseBody
	@PostMapping("ex05")
	public ArrayList<JsonExamDTO> ex05(@RequestBody(required = false) String data) {
		
		ClassPathResource cpr = new ClassPathResource("static/jsonExam.json");
		ObjectMapper om = new ObjectMapper();
		ArrayList<JsonExamDTO> infos = null;
		try {
			
	infos = om.readValue(cpr.getFile(), new TypeReference<ArrayList<JsonExamDTO>>() {});
	
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return infos;
	}
	
	@GetMapping("ex06")
	public String ex06() {
		return "ex06";
	}
	
	@ResponseBody
	@PostMapping("ex06")
	public String ex06(@RequestBody(required = false) String data) {
		String message = service.insert();
		return message;
	}
	
	@GetMapping("ex07")
	public String ex07() {
		return "ex07";
	}
	
	/*
	service.selectAll Method 생성
	그 안에 mapper.selectAll();  호출
	mapper.selectAll(); 호출 후 결과를 Controller에 반환하겠다.
 */
	@ResponseBody
	@PostMapping("ex07")
	public ArrayList<JsonExamDTO> ex07(@RequestBody(required = false) String data) {
		ArrayList<JsonExamDTO> infos = service.selectAll();
		return infos;
	}
	
	/*
	 * 첫 화면 또는 input에 아무것도 입력이 안되어 있으면 모든 데이터 출력하기.
	 * input 에 입력한 글자를 포함한 데이터가 있으면 모두 출력하기.
	 */

	@GetMapping("quiz")
	public String quiz() {
		return "quiz";
	}

	@ResponseBody
	@PostMapping("quiz")
	public ArrayList<JsonExamDTO> quiz(
			@RequestBody(required = false) String title) {
		
		ArrayList<JsonExamDTO> infos = null;
		
		if(title == null) {
			 infos = service.selectAll();
		}else {
			infos = service.quiz(title);
		}
		return infos;
	}
	
}








