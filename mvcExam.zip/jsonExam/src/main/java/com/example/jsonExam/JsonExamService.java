package com.example.jsonExam;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class JsonExamService {

	// JsonExamMapper 생성, 그 안에 Method 생성
	// jsons.xml 파일 생성, 그 안에 아래의 SELECT 명령문 작성.
	
	@Autowired JsonExamMapper mapper;
	
	public String ex02(String id) {
		if(id == null) {
			return "데이터를 입력하세요.";
		}
		// SELECT COUNT(username) FROM member WHERE id='admin';
		int count = mapper.ex02(id);
		System.out.println("데이터베이스의 전달해준 결과값 : " + count);

		if(count == 1) {
			return "아이디가 존재합니다.";
		}
		
		return "아이디를 사용 할 수 있습니다.";
	}

	public String insert() {
		
		// 파일의 데이터를 읽어서 ArrayList<JsonExamDTO> infos에 저장했다.
		ClassPathResource cpr = new ClassPathResource("static/jsonExam.json");
		ObjectMapper om = new ObjectMapper();
		ArrayList<JsonExamDTO> infos = null;
		try {
			
			infos = om.readValue(cpr.getFile(), 
					new TypeReference<ArrayList<JsonExamDTO>>() {});
	
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		mapper.deleteAll(); // 테이블의 데이터를 모두 삭제하겠다.
		
		for(JsonExamDTO info: infos) {
			int row = mapper.insert(info);
			if(row == 0) {
				return "오류가 발생했습니다. 관리자에게 문의하세요.";
			}
		}
		
		return "정상적으로 데이터가 모두 입력 되었습니다.";
		
	}

	public ArrayList<JsonExamDTO> selectAll() {
		ArrayList<JsonExamDTO> infos = mapper.selectAll();
		return infos;
	}

	public ArrayList<JsonExamDTO> quiz(String title) {
		return mapper.quiz(title);
	}
}






