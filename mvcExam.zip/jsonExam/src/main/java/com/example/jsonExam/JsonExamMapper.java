package com.example.jsonExam;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface JsonExamMapper {

	public int ex02(String id) ;
       
	public void deleteAll();

	public int insert(JsonExamDTO info);

	public ArrayList<JsonExamDTO> selectAll();

	public ArrayList<JsonExamDTO> quiz(String title);

}
/*
CREATE TABLE json_table(
title VARCHAR(50),
artist VARCHAR(50),
price VARCHAR(50)
)DEFAULT CHARSET=UTF8;
*/


