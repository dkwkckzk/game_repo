package com.example.mvcExam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
