package com.example.mvcExam;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.servlet.http.HttpSession;

@Service
public class MvcService {
	
	@Autowired	IMvcMapper mapper;

	public String registProc(MvcDTO members) {
		System.out.println("현재 위치는 MvcService 안에 registProc()");
		System.out.println("아이디 : " + members.getId());
		
		//  서버측 데이터 검증
		if(members.getId().isEmpty() == true) { 
			return "아이디를 입력하세요";
		}
		
		String regex = "^[a-z0-9_-]{5,20}$";
		// regex 변수의 정규표현식 해석
		Pattern pattern = Pattern.compile(regex);
		// 해석 후 id 변수에 담긴 문자열과 비교
		Matcher matcher = pattern.matcher( members.getId() );
		// 비교 결과를 출력(true(일치), false(불일치))
		if(matcher.matches() == false) {
			return "아이디: 5~20자의 영문 소문자, 숫자와 특수기호(_),(-)만 사용 가능합니다.";
		}
		
		// 데이터 암호화
		// 외부 정보(카카오, 네이버, 구글 등) 요청/응답
		
		// 중복 아이디 체크(데이터베이스에 회원가입을 할 아이디가 존재하는지 여부 체크)
		MvcDTO result = mapper.loginProc(members.getId());
	
		if(result == null) {
			// 데이터베이스 회원 정보 저장
			int row = mapper.registProc(members);
			System.out.println("Insert 명령 후 반환 데이터 : " + row);// 정상적인 회원가입 시 출력
			if(row == 1)
				return "회원정보 저장 완료";
			return "데이터베이스에서 입력 실패 ";
		}
		
		// 중복 데이터 입력 시 출력
		System.out.println("아이디 : " + result.getId());
		System.out.println("이름 : " + result.getUserName());
		System.out.println("상세주소 : " + result.getDetailAddress());
		
		return "아이디를 변경 후 재가입하세요.";
	}

	public ArrayList<MvcDTO> memberInfo() {
		ArrayList<MvcDTO> database = mapper.memberInfo();
		return database;
	}
	
	
	public String loginProc(String id, String pw) {
		// 데이터베이스 조회 전에 사용자가 전달해준 데이터 검증 
		if(id.isEmpty() == true) { 
			return "아이디를 입력하세요";
		}
		if(pw.isEmpty() == true) { 
			return "비밀번호를 입력하세요";
		}
		
		MvcDTO result = mapper.loginProc(id);
		if(result == null) {
			return "아이디 또는 비밀번호를 확인 후 다시 시도하세요.";
		}
		
		if( pw.equals( result.getPw() ) == true) {
			session.setAttribute("id", result.getId());
			session.setAttribute("userName", result.getUserName());
			session.setAttribute("address", result.getAddress());
			session.setAttribute("mobile", result.getMobile());
			
			return "로그인 성공";
		}
		return "아이디 또는 비밀번호를 확인 후 다시 시도하세요.";
	}
	@Autowired HttpSession session;

	public String updateProc(MvcDTO members) {
		// 검증의 코드들은 생략
		
		// update.jsp name속성을 설정x, id
		// 로그인 시 저장한 세션의 아이디를 members에 담아주기.
		members.setId( (String)session.getAttribute("id") );
		int row = mapper.updateProc(members);
		if(row == 1) {
			return "회원정보 수정 완료";
		}
		return "원할한 서비스가 진행되지 않았습니다. 다시 시도해주세요";
	}
	
	
	// update를 확인하고 delete를 만들어보자.
	public String deleteProc(MvcDTO members) {
		// 사용자가 입력한 비밀번호 두 개 같은지 비교
		if(members.getPw().equals(members.getConfirm()) == false) {
			return "비밀번호를 확인 후 다시 시도하세요.";
		}
		
		MvcDTO dbData = mapper.loginProc(members.getId());
		if(dbData == null) {
			return "원할한 서비스가 진행되지 않았습니다. 다시 시도해주세요.";
		}
		
		// 데이터베이스에 저장된 PW, 사용자가 입력한 PW 비교
		if(dbData.getPw().equals(members.getPw()) == true)  {
			int row = mapper.deleteProc(members.getId());
			if(row == 1)
				return "회원정보 삭제 완료";
			if(row == 0)
				return "원할한 서비스가 진행되지 않았습니다. 다시 시도해주세요.";
		}
		
		return "비밀번호를 확인 후 다시 시도하세요.";
	}
	
}













