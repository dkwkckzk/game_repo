package com.example.mvcExam;
/*
 * 
CREATE TABLE mvcexam(
    id varchar2(20),
    pw varchar2(100),
    username varchar2(50),
    postcode varchar2(10),
    address varchar2(300),
    detailaddress varchar2(300),
    mobile varchar2(20),
    PRIMARY KEY(id)
);
DROP TABLE mvcExam;

INSERT INTO mvcexam 
VALUES('admin', '1234', '관리자', '12345', '서울시', 
'401호', '010-0000-0000');

COMMIT;

SELECT * FROM mvcexam;
 */
public class MvcDTO {
	private String id;
	private String pw;
	private String confirm;
	private String userName;
	private String postcode;
	private String address;
	private String detailAddress;
	private String mobile;
	
	// Alt + Shift + s -> Generate Getters and Setters 
	// -> select all 선택 -> generate 선택

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getConfirm() {
		return confirm;
	}
	public void setConfirm(String confirm) {
		this.confirm = confirm;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDetailAddress() {
		return detailAddress;
	}
	public void setDetailAddress(String detailAddress) {
		this.detailAddress = detailAddress;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	
}
