package com.example.mvcExam;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface IMvcMapper {
	
	MvcDTO loginProc(String id);

	int registProc(MvcDTO members);

	ArrayList<MvcDTO> memberInfo();

	int updateProc(MvcDTO members);

	int deleteProc(String id);
	
}
















