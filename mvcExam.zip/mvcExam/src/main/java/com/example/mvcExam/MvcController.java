package com.example.mvcExam;

import org.springframework.ui.Model;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class MvcController {

	@Autowired
	MvcService service;

	@RequestMapping("header")
	public String header() {
		return "default/header";
	}

	@RequestMapping("footer")
	public String footer() {
		return "default/footer";
	}

	@RequestMapping("main")
	public String main() {
		return "default/main";
	}

	@RequestMapping("index")
	public String index() {
		return "index";
	}

	@GetMapping("regist")
	public String regist() {
		return "member/regist";
	}

	@PostMapping("registProc")
	public String regist(MvcDTO members, Model model) {

		String result = service.registProc(members);
		if (result.equals("회원정보 저장 완료") == true)
			return "index"; // or return "member/login";

		return "member/regist";

	}

	@GetMapping("memberInfo")
	public String memberInfo(Model model) {
		ArrayList<MvcDTO> database = service.memberInfo();
		model.addAttribute("members", database);
		return "member/memberInfo";
	}

	@GetMapping("login")
	public String login() {
		return "member/login";
	}

	@PostMapping("loginProc")
	public String login(String id, String pw, Model model) {

		String result = service.loginProc(id, pw);
		if (result.equals("로그인 성공") == true)
			return "index";

		return "member/login";
	}



	@RequestMapping("logout")
	public String logout() {
		session.invalidate(); // 지금 계정의 세션 정보 모두 삭제
		return "redirect:index";
	}

	@GetMapping("update")
	public String update() {
		// 로그인 안 했으면 로그인 페이지로 이동
		String id = (String) session.getAttribute("id");
		if (id == null || id == "") {
			return "member/login";
		}
		return "member/update";
	}

	@PostMapping("updateProc")
	public String update(MvcDTO members, Model model) {
		// 로그인 안 했으면 로그인 페이지로 이동
		String id = (String) session.getAttribute("id");
		if (id == null || id == "") {
			return "member/login";
		}

		String result = service.updateProc(members);
		if (result.equals("회원정보 수정 완료") == true) {
			session.invalidate(); // 로그 아웃
			return "member/login";
		}

		return "member/update";

	}
	
	@Autowired	HttpSession session;
	
	@GetMapping("delete")
	public String delete() {
		// 로그인 안 했으면 로그인 페이지로 이동
		String id = (String) session.getAttribute("id");
		if (id == null || id == "") {
			return "member/login";
		}
		return "member/delete";
	}

	@PostMapping("deleteProc")
	public String delete(MvcDTO members, Model model) {
		// 로그인 안 했으면 로그인 페이지로 이동
		String id = (String) session.getAttribute("id");
		if (id == null || id == "") {
			return "member/login";
		}

		members.setId(id);
		String result = service.deleteProc(members);
		if (result.equals("회원정보 삭제 완료") == true) {
//			session.invalidate(); // 로그 아웃
//			return "member/index";
			return "forward:logout";
		}

		return "member/delete";
	}
}





