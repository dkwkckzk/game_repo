package com.example.mvcExam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcExamApplication.class, args);
	}

}
