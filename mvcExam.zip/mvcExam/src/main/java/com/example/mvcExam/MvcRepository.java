package com.example.mvcExam;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;


public class MvcRepository {
	private ArrayList<MvcDTO> database;
	
	public MvcRepository() {
		database = new ArrayList<>();
		MvcDTO member = new MvcDTO();
		member.setId("admin");
		member.setPw("1234");
		member.setConfirm("1234");
		member.setUserName("관리자");
		member.setMobile("010-1234-1234");
		member.setPostcode("12345");
		member.setAddress("서울시");
		member.setDetailAddress("401호");
		database.add(member);
	}
	
	public void registProc(MvcDTO members) {
//		System.out.println("현재 위치는 MvcRepository 안에 registProc()");
//		System.out.println("아이디 : " + members.getId());
//		System.out.println("비밀번호 : " + members.getPw());
		database.add(members);
	}

	// 데이터베이스에서 회원 정보 중에 입력한 아이디와 같은게 있으면 그 아이디에 대한 모든 회원정보를 반환
	// 같은게 없다면 null을 반환한다.
	public MvcDTO selectOne(String id) {
		for(MvcDTO search : database) {
			if(search.getId().equals(id) == true) {
				return search;
			}
		}
		return null;
	}

	public ArrayList<MvcDTO> memberInfo() {
		return database;
	}

	
	
}











