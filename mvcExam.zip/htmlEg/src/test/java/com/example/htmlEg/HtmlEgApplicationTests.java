package com.example.htmlEg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HtmlEgApplicationTests {

	@Test
	void contextLoads() {
	}

}
