package com.example.html;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HtmlExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
