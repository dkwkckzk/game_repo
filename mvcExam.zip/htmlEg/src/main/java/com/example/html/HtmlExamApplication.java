package com.example.html;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HtmlExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(HtmlExamApplication.class, args);
	}

}
