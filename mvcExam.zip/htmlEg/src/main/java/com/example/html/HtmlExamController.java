package com.example.html;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

@Controller
public class HtmlExamController {

	@GetMapping("ex01")
	public String exam1() {
		
		
		return "ex01";
	}
	
	@GetMapping("ex02")
	public String exam2() {
		return "ex02";
	}
	
	@GetMapping("ex03")
	public String exam3() {
		return "ex03";
	}
	
	@GetMapping("ex04")
	public String exam4() {
		return "ex04";
	}
	
	@GetMapping("ex05")
	public String exam5() {
		return "ex05";
	}
	
	@GetMapping("ex06")
	public String exam6() {
		return "ex06";
	}
	
	@GetMapping("ex07")
	public String exam7() {
		return "ex07";
	}
	
	@GetMapping("ex08")
	public String exam8() {
		return "ex08";
	}
	@GetMapping("ex09")
	public String exam9() {
		return "ex09";
	}
	@GetMapping("quiz1")
	public String quiz1() {
		return "quiz1";
	}
}









