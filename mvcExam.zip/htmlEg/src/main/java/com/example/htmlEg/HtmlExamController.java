package com.example.htmlEg;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@Controller
public class HtmlExamController {
	@GetMapping("ex01") // 데이터 양이 적거나 화면을 전달
	public String exam01() {
		return "ex01";
	}
	
	@GetMapping("ex02")
	public String exam02() {
		return "ex02";
	}
	
	@GetMapping("ex04")
	public String exam07() {
		return "test";
	}
	
	@GetMapping("ex05")
	public String exam12() {
		return "quiz2";
	}
	
	@GetMapping("ex11")
	public void exam11(String id, String pw) {
		// 출력해줘. 
		System.out.println(id);
		System.out.println(pw);
		// 전달하는 jsp파일(값)이 없어 화면에 출력되지 않음.
	}

	// PostMapping 파일을 전달할 때 사용
}
