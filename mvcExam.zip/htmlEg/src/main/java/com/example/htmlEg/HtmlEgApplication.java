package com.example.htmlEg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HtmlEgApplication {

	public static void main(String[] args) {
		SpringApplication.run(HtmlEgApplication.class, args);
	}

}
