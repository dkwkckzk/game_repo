package com.example.jsExam;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class JsController {

	@GetMapping("ex01")
	public String ex01() {
		return "ex01";
	}
	@GetMapping("ex02")
	public String ex02() {
		return "ex02";
	}
	@GetMapping("ex03")
	public String ex03() {
		return "ex03";
	}
	@GetMapping("ex04")
	public String ex04() {
		return "ex04";
	}
	@GetMapping("ex05")
	public String ex05() {
		return "ex05";
	}
	
	@GetMapping("ex06")
	public String ex06() {
		return "ex06";
	}
	@GetMapping("ex07")
	public String ex07() {
		return "ex07";
	}
	@GetMapping("ex08")
	public String ex08() {
		return "ex08";
	}
	@GetMapping("ex09")
	public String ex09() {
		return "ex09";
	}
	@GetMapping("ex10")
	public String ex10() {
		return "ex10";
	}
	@GetMapping("ex11")
	public String ex11() {
		return "ex11";
	}
	@GetMapping("ex12")
	public String ex12() {
		return "ex12";
	}
	@GetMapping("ex13")
	public String ex13() {
		return "ex13";
	}
	@GetMapping("ex14")
	public String ex14() {
		return "ex14";
	}
	
	@GetMapping("ex15")
	public String ex15() {
		return "ex15";
	}
	@GetMapping("ex16")
	public String ex16() {
		return "ex16";
	}
	@GetMapping("ex17")
	public String ex17() {
		return "ex17";
	}
	@GetMapping("ex18")
	public String ex18() {
		return "ex18";
	}
	@GetMapping("ex19")
	public String ex19() {
		return "ex19";
	}
	@GetMapping("ex20")
	public String ex20() {
		return "ex20";
	}
	@GetMapping("ex21")
	public String ex21() {
		return "ex21";
	}
	@GetMapping("ex22")
	public String ex22() {
		return "ex22";
	}
	@GetMapping("ex23-1")
	public String ex23_1() {
		return "ex23-1";
	}
	@GetMapping("ex23-2")
	public String ex23_2() {
		return "ex23-2";
	}
	@GetMapping("ex24")
	public String ex24() {
		return "ex24";
	}
	@GetMapping("ex25")
	public String ex25() {
		return "ex25";
	}
	@GetMapping("ex26-1")
	public String ex26_1() {
		return "ex26-1";
	}
	@GetMapping("ex26-2")
	public String ex26_2() {
		return "ex26-2";
	}
	@GetMapping("ex27")
	public String ex27() {
		return "ex27";
	}
	@GetMapping("ex28_regist")
	public String ex28_regist() {
		return "ex28_regist";
	}

	
	@GetMapping("ex28_header")
	public String ex28_header() {
		return "ex28_header";
	}
	
	@GetMapping("ex28_footer")
	public String ex28_footer() {
		return "ex28_footer";
	}
	
	@GetMapping("ex28_login")
	public String ex28_login() {
		return "ex28_login";
	}
	
	
	@GetMapping("quiz1_button")
	public String quiz1_button() {
		return "quiz1_button";
	}
	@GetMapping("quiz1_register")
	public String quiz1_register() {
		return "quiz1_register";
	}
	@GetMapping("quiz1_success")
	public String quiz1_success() {
		return "quiz1_success";
	}
	@GetMapping("quiz2")
	public String quiz2() {
		return "quiz2";
	}
}








