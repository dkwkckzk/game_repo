package com.example.jsExam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsExamApplication.class, args);
	}

}
